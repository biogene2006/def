import numpy as np 

mLI_r = np.array([[0.74, 0.28562048545608515], [0.74, 0.28646290736028]]) 
