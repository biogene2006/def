# -*- coding: utf-8 -*-
"""
Created on Sat May 11 15:35:53 2019

@author: ash
"""
#import Main
tpsEntreMesures = 2; 
# nb d'oscillations minimum à imposer lors du calibrage
nbOscillations = 7; 

import math
import matplotlib.pyplot as plt
import numpy as np
#import parametre
plt.ion()
global typeTest
# script utilisé lors de calibrage (raquette ou balle) pour trouver les propriétés
# de masse, inertie, et rendement des 2 axes
# les données sont dans la variable 'mesures' qui sort de la fonction 'Acquisition'

def plot_simple (to_plot):
#    plt.figure(1)
#    plt.figure( figsize=(8, 6))
    plt.plot(to_plot,'k' )
    plt.show()

# si calibrage raquette, demande autres informations

print ("=========calibration=======")
#typeTest =2
if typeTest==2 :
    print('*******************************************************')
    mRaquette=input('Masse de la raquette ? (en g) ==> ') 
    posCdGRaquette=input('Position du centre de gravité de la raquette ? (en mm) ==> ')
    print('*******************************************************')
# open file
from pathlib import Path

a = np.array([])
Temps=[]
data_folder = Path("source_data/text_files/")
p = Path('.')
print (p.absolute())
if typeTest==1 :
    file_to_open = p.absolute() / "calib_bal_p.txt"
if typeTest==2 :
    file_to_open = p.absolute() / "calib_raq_p.txt"

global temps
global raquette
global balle
global accelero
        
if typeTest == 1 :
    a = balle
if typeTest == 2 :
    a = raquette
        
Temps = temps
## ========================================================================
# cherche le nombre de tests et les intervales intéressants
# =========================================================================
ang=np.radians(a); # angle en radian

# fait la moyenne des n premieres valeurs pour trouver celle au repos
#ang0=mean(ang(t<(tpsRepos),1));
ang0 = (np.mean(ang[0:1000]))
# soustrait à toutes les autres pour mettre le repos sur angle=0
#ang=ang-ang0;
ang = np.subtract(ang, ang0)
ang = ang*-1
# cherche les pics de la courbe d'oscillations libres amorties
#ind=peakfinder(ang,0.3);
#ind=[1;ind]; # rajoute l'indice 0 en début
plot_simple(ang)
from detect_peaks import detect_peaks
indexes = detect_peaks(ang, mph=0.15 , mpd=1000)

pic = np.array([])
indexes = np.append(0, indexes)

for i in indexes:
    pic = np.append(pic, ang[i])
# cherche ceux pour lesquels il n'y a pas de pics juste avant
#indSub=ind(2:end)-ind(1:end-1); # difference des indices où les pics sont trouvés*
indSub = indexes[1:]-indexes[0:-1]

time = np.arange(0.0, len(a), 1)

#plt.figure(1)
#plt.figure( figsize=(8, 6))
#plt.plot(time , ang,'k', indexes, pic , 'ro',)

# pas de pics si le debut entre 2 max consecutifs est grand
#periode=indSub*(t(2,1)-t(1,1)); # diff des indices *  tps increment => periode en us

#indTest1erPic=ind(find((periode)>tpsEntreMesures)+1); # indices des débuts de tests
indTest1erpic = np.array([])
total_time=0;
for indexe in indSub:
    total_time +=indexe 
    if indexe > (tpsEntreMesures +1) *1000:
        indTest1erpic = np.append(indTest1erpic , total_time)

nbTests=len(indTest1erpic) ; # nombre de tests
print("nombre de test = ", nbTests)

# je choisis de commencer l'acquisition non pas sur le premier pic, mais
# sur le premier 0 d'après pour éviter certains problèmes de conditions limites

indMes0 =np.array([])
for counter, angl in enumerate(ang):
    if  ang[counter]  < 0 :
        indMes0 = np.append(indMes0 , counter)

# pour chaque test, je cherche le 0 juste après le indTest1erPic
# la premiere valeur où ca croise l'axe est la valeur interessante
ind0=np.array([])
val_ind0=np.array([])
for i in range (nbTests):
    val = np.array([])
    for indi in(indMes0):
#        print ('indi = ' , indi)
        if indi >  indTest1erpic[i]:
            val = np.append(val, indi)
            #print("find indi sup a indtest1piec", indTest1erpic[i])
    ind0 = np.append(ind0, val[1])    
    val_ind0 = np.append(val_ind0 , ang[int(val[1])])

# regarde si la valeur juste avant le ind0 (soit juste avant l'axe n'est pas mieux) 
indTestFin = np.array([]) 
valTestFin = np.array([])
for n in range (nbTests):
    for i , ind in enumerate (indexes):
        if ind == indTest1erpic[n] : 
            indTestFin = np.append(indTestFin , indexes[i + nbOscillations])
            valTestFin = np.append(valTestFin , ang[indexes[i + nbOscillations]])
    
indAEnlever = np.array([])
mLI = np.zeros((nbTests,2),)
rendement = np.zeros((nbTests,1))

for num_Test in range (nbTests):
    print("***********************")
    print("Pour le test  ", num_Test + 1)

#    t_test = np.arange(int(ind0[num_Test]), int(indTestFin[num_Test]),0.001  )
#    temp = ((int(indTestFin[num_Test]) - int(ind0[num_Test])) ) / 1000
#    temp_test = np.arange(0,temp , step = 1 / 1000 ) 
    ang_test =   - ang [ int (ind0[num_Test]) : int (indTestFin [num_Test]) ]
#-----nouvelle version avec temp reel
    t_test = Temps[ int(ind0[num_Test]): int(indTestFin[num_Test]) ] 
    temp =  (t_test[-1]-t_test[0])/1000
    t_test = np.asarray(t_test)
    temp_test= t_test - t_test[0]
    temp_test = temp_test 
#------fin nouvelleversion
    
    ind_n =detect_peaks(ang_test, mph=0.3 , mpd=1000) ;
    pic_n = np.array([])
    for i in ind_n :
        pic_n = np.append ( pic_n ,ang_test[i])
    # => rendement calculé pour 1/4 d'oscillations (de haut en bas 1 fois) en suivant une
    # interpolation lineaire sur les courbes d'oscillations) : les pertes sont approximées linéairement
    rendement[num_Test] = math.pow( ((1-math.cos(pic_n[-1])))/(1-math.cos(pic_n[1])) , 1/(4*(nbOscillations - 1)) )
    
    # périodes de chaque oscillation
    diffT = np.array([])
    diffT =  t_test[ind_n[2:]] -t_test[ind_n[1:-1]]
    T = np.mean(diffT) / 1000# moyenne des périodes

    # -------- Calcul courbe de regression
    
    # valeurs initiales et bornes pour l'algorithme d'optimisation
    if typeTest == 1 :
        mLinit=mTigePendule*(posCdGTigePendule+mBoule*posCdGBoule); # mL est imposé
        mL = mLinit 
        kvlinit = 0.01
        Iinit = 0.55
        cmin = [mL, 0,    0.4,  -0.01,  1]
        cmax = [mL, 0.02, 0.7  ,   0.01,  5]
        cmin = [mL, 0,    0.5,  -0.01,  1]
        cmax = [mL, 0.02, 0.6,   0.01,  3.5]
    if typeTest == 2 :
        mLinit=float(mRaquette)*1e-3*(float(posCdGRaquette)*1e-3+float(posRaquette))+float(mBras)*float(posCdGBras); # mL est imposé
        mL = mLinit 
        mL = 0.74
        kvlinit = 0.035
        Iinit=float(math.pow(T,2))*float(mLinit)*9.81/(4*math.pow(math.pi,2));      # T période moyenne          
#        Iinit=0.30;      # T période moyenne        
        cmin = [mL, 0.03, 0.2, -0.01,  2]
        cmax = [mL, 0.04, 0.3,  0.01,  4]
    pos0init=0;
    vit0init = (ang_test[10] - ang_test[0]) / (t_test[10]/1000 - t_test[0]/1000)

    def EDCoulomb(t,x,param):
        g = 9.81
        mL = param[0]
        kv1 = param[1]
        I = param[2]
        
        theta = x[0] # angle
        dtheta = x[1] # vitesse
        ddtheta=-mL * g / I * math.sin(theta) - kv1 / I * dtheta # acceleration

        return (dtheta , ddtheta)
    def Myfun2Minimize(c,donnees):
#        param = (mL , kvlinit , Iinit)
#        print ("donnes =" , c)
        param = (c[0], c[1] , c[2])
        t0 = 0.0 
        tmax = 14.0
        from scipy import integrate
        #from scipy.integrate import odeint
        solED = integrate.solve_ivp(lambda t, y:EDCoulomb(t,y,param) , (t0, tmax) , (c[3], c[4])  , max_step = 0.001,dense_output=True, rtol = 1e-5,atol = 1e-8)    
#        print( solED)
#        fxi  = solED.y[0][:len (ang_test)]
#        res  = np.sum(fxi-ang_test)*math.ceil(math.log2(abs(2)))  
        from scipy.integrate import odeint
#        XsolED = odeint(solED, 0, len (donnees[1]))
        fxi  = solED.y[0][:len (donnees[1])]
#        res  = np.sum(fxi-donnees[1])*math.ceil(math.log2(abs(2))) 
        res = 0
        for i in range(len (fxi)):
            res += math.pow((fxi[i]-donnees[1][i]) , 2)
        print ("res =" , res)
        return res
    """
        # utilisation de fminsearchbnd
    options=optimset('fminsearch');
    options.TolFun=1e-2; options.TolX=1e-2; options.TolCon=1e-2; # options de convergence
    [xsol,fval]=fminsearchbnd(@(x)Myfun2Minimize(x,[t_test,ang_test]),[mLinit,kv1init,Iinit,pos0init,vit0init],cmin,cmax,options);
    # si je ne veux pas lancer l'optimisation mais utiliser des valeurs approchées
    """
    from scipy import optimize
    from scipy.optimize import Bounds
#    bounds = Bounds([mL, 0.03,    0.2,  -0.01,  2], [mL, 0.04,    0.3,   0.01,  4])
    bounds = Bounds(cmin, cmax)
    
#    (xsol , fval) = optimize.fmin(lambda x : Myfun2Minimize ( x, [t_test , ang_test]) ,[mLinit,kvlinit,Iinit,pos0init,vit0init], ftol = 1e-2 , xtol = 1e-2  )    
#    xsol = optimize.fmin(lambda x : Myfun2Minimize ( x, [t_test , ang_test]) ,[mLinit,kvlinit,Iinit,pos0init,vit0init] )    
#    xsol = optimize.minimize(lambda x : Myfun2Minimize ( x, [t_test , ang_test]) ,[mLinit,kvlinit,Iinit,pos0init,vit0init] , bounds=bounds, tol = 1e-2  )
#    xsol = optimize.minimize(lambda x : Myfun2Minimize ( x, [t_test , ang_test]) ,[mLinit,kvlinit,Iinit,pos0init,vit0init] , method='Nelder-Mead' , tol = 1e-2, bounds=bounds,options={ 'xatol': 1e-2, 'fatol': 1e-2}  )    
    xsol = optimize.minimize(lambda x : Myfun2Minimize ( x, [temp_test , ang_test]) ,[mLinit,kvlinit,Iinit,pos0init,vit0init],  method='L-BFGS-B', bounds=bounds,options={'ftol': 1e-2}  )
    
    
#    print ("resultat optimisation = ", xsol) 
#    print ("totut de x = ", xsol.x) 

    Ifmincon=xsol.x[2]
    mLfmincon=xsol.x[0]
    c=xsol.x
    paramR=(c[0:3])
    pos0R=c[3]
    vit0R=c[4]
    
    mLI[num_Test] =[mLfmincon , Ifmincon]
    from scipy import integrate
    solEDR = integrate.solve_ivp(lambda t, y:EDCoulomb(t,y,paramR) , (0, temp) , (pos0R, vit0R)  , dense_output = True, max_step = 0.001, rtol = 1e-8,atol = 1e-10)    

    time = np.arange(0.0, len(a), 1)
    
#    plt.figure(1)
#    plt.figure( figsize=(8, 16))
#    #plt.gcf().subplots_adjust(wspace = 0, hspace = 4)
##    
#    plt.subplot(611)
#    plt.ylabel('teta')
#    plt.plot(time ,  a,'k' )
#    
#    plt.subplot(612)
#    plt.ylabel('teta')
#    plt.plot(time , ang,'k', indexes, pic , 'ro', ind0 , val_ind0 ,'bo' , indTestFin , valTestFin , 'go' )
#    
#    plt.subplot(613)
#    plt.ylabel('teta')
#    plt.plot( temp_test ,  ang_test ,'k', temp_test[ind_n], pic_n ,'ro' )
##    plt.plot( temp_test ,  ang_test ,'k' )
#    
#    plt.subplot(614)
#    plt.ylabel('teta')
#    plt.plot( temp_test ,  ang_test ,'k' )
#    
#    plt.subplot(615)
#    plt.ylabel('accel')
#    plt.plot( solEDR.t ,  solEDR.y[0] ,'k' )
    
#    plt.subplot(616)
    plt.ylabel('les deux')
#    plt.plot( solEDR.t ,  solEDR.y[1] ,'k' )
#    plt.plot( temp_test/1000 ,  ang_test ,'k' )
#    plt.plot( solEDR.t ,  solEDR.y[0] ,'b' )
    plt.plot( temp_test/1000 ,  ang_test ,'k' , solEDR.t ,  solEDR.y[0] ,'b' )
    plt.show()
    print ("rendement = " , rendement)
    print ("mLI =" , mLI)
    print ("file tot write")

## ========================================================================
#  post-processing, enregistrement
# =========================================================================
# enregistre ces valeurs en dur dans le workspace
    print("***********************")

import os.path
print ("typeTest=",typeTest)
if typeTest == 1 : #balle
    print ("type=test =",typeTest)
    if os.path.isfile('mLI_balle.py'):# recupere précédentes valeurs
        from mLI_balle import mLI_b
        print('*******************************************************')
        print('les valeurs caractéristiques du dernier calibrage balle étaient ', mLI_b)
    print('*******************************************************')
    print('les nouvelles valeurs du calibrage balle sont:' , mLI)
    print('*******************************************************')   
    if os.path.isfile('rendement_balle.py'):
        from rendement_balle import rendement_b
        print('*******************************************************')
        print('les valeurs caractéristiques du dernier rendement balle étaient ', rendement_b)
    print('*******************************************************')
    print('les nouvelles valeurs du rendement balle sont:' , rendement)
    print('*******************************************************')  
    
    testSauve=input('Voulez-vous les sauvegarder ? (1 si OUI) ');
#    testSauve=1;
    if int(testSauve) == 1 :
        file_to_write = open("mLI_balle.py","w+")
#        file_to_write.write("mLI_b = " + (mLI) + "\n")
        file_to_write.write("import numpy as np \n")
        file_to_write.write("\n" + "mLI_b = np.array(" + str((mLI.tolist())) + ") \n")
        file_to_write.flush()
        file_to_write.close()
        file_to_write = open("rendement_balle.py","w+")
#        file_to_write.write("rendement_b = " + repr(rendement) + "\n")
        file_to_write.write("import numpy as np \n")
        file_to_write.write("\n" + "rendement_b = np.array(" + str((rendement.tolist())) + ") \n")
        file_to_write.close()
if typeTest == 2 : #raquette
    print ("type=test =",typeTest)
    if os.path.isfile('mLI_raquette.py'):# recupere précédentes valeurs
        from mLI_raquette import mLI_r
        print('*******************************************************')
        print('les valeurs caractéristiques du dernier calibrage raquette étaient ', mLI_r)
    print('*******************************************************')
    print('les nouvelles valeurs du calibrage requette sont:' , mLI)
    print('*******************************************************')   
    if os.path.isfile('rendement_raquette.py'):
        from rendement_raquette import rendement_r
        print('*******************************************************')
        print('les valeurs caractéristiques du dernier rendement raquette étaient ', rendement_r)
    print('*******************************************************')
    print('les nouvelles valeurs du rendement raquette sont:' , rendement)
    print('*******************************************************')  
    
    testSauve=input('Voulez-vous les sauvegarder ? (1 si OUI) ');
    
#    testSauve=1;
    if int(testSauve) == 1 :
        file_to_write = open("mLI_raquette.py","w+")
        file_to_write.write("import numpy as np \n")
        file_to_write.write("\n" + "mLI_r = np.array(" + str((mLI.tolist())) + ") \n")
        file_to_write.flush()
        file_to_write.close()
        file_to_write = open("rendement_raquette.py","w+")
        file_to_write.write("import numpy as np \n")
        file_to_write.write("\n" + "rendement_r = np.array(" + str((rendement.tolist())) + ") \n")
        file_to_write.close()
