import numpy as np 

rendement_b = np.array([[0.9920471400037645], [0.98921769402042]]) 
