import numpy as np 

rendement_r = np.array([[0.9619310356550396], [0.963506117219403]]) 
